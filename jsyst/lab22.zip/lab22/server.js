var bodyParser = require('body-parser'),
    express = require('express')
  , app = express()
  , port = process.env.PORT || 3000,
    solution=require('./lib.js');



app.use(bodyParser.urlencoded({extended: false}));
app.use(express.static(__dirname + "/public"));
app.set('view engine', 'ejs');


app.listen(port, function () {
  console.log('Listening on port ', port)
})

app.post('/solution',function (req,res,next){
    function toFunc(data){
        return function(t,x,y){
            return eval(data)
        }
    }
    var h = parseFloat(req.body.h),
        e = parseFloat(req.body.e),
        lim = 0.01,
        x0 =parseFloat(req.body.x0),
        y0 =parseFloat(req.body.y0),
        f=null,
        g=null,
        ft=null,
        gt=null,
        res=null;

    try{
        f=function(t,x,y){
            return eval(req.body.f);
        }
        g=function(t,x,y){
            return eval(req.body.g);
        }
        ft=function(t){
            return eval(req.body.ft);
        }
        gt=function(t){
            return eval(req.body.gt);
        }
        result=solution(h,e,lim,x0,y0,f,g,ft,gt);
        if (result){
            res.render('main',{solution : result}); 
        } else {
            res.redirect('/');   
        }
        
      } catch (e){
        console.log(e);
         console.log("Invalid functions,use JS sintaxis ( with Math. lib)");
          res.redirect('/')
      }
});
