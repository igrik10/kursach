Array.prototype.max = function() {
    var max=this[0];
    this.forEach(function(elem){
        if (elem>max){
            max=elem;
        }
    });
    return max;
};
function Result(h,t,x,y,xt,yt,rx,ry){
    this.h=h;
    this.t=t;
    this.x=x;
    this.y=y;
    this.xt=xt;
    this.yt=yt;
    this.rx=rx;
    this.ry=ry;

    return this;
}
var calculate=function(h,e,lim,x0,y0,f,g,ft,gt){
    var  x=[], y=[], xstart, ystart, x1, y1, x0,y0, xka, yka,w=[],F=[];
    var i, n, decimal = 0;

    xstart = x0 + h*f(0,x0,y0);
    ystart = y0 + h * g(0, x0, y0);

        do{
                x1 = xstart;
                y1 = ystart;
                h = h / 2;

                xstart = x0 + h * f(0, x0, y0);

                ystart = y0 + h * g(0, x0, y0);

                x[1] = xstart + h * f(h, xstart, ystart);

                y[1] = ystart + h * g(h, xstart, ystart);

        }while(Math.abs(x[1]-x1)+Math.abs(y[1]-y1)>=e);
        n = 1/h +1;
        x[0] = x0;
        y[0] = y0;
        
        x[2] = x[1] + h * g(h, x[1], y[1]);
        y[2] = y[1] + h * g(h, x[1], y[1]);
        var  delta = 5/1001.0, hmax = delta / 2.0;
        var sw = 0;
        var xt=[],yt=[];
        for(i=3; i< n; i++)
        {
                x[i] = x[i-1];
                y[i] = y[i-1];

                do         //Ìåòîä Íüþòîíà
                {
                        xka = x[i];
                        yka = y[i];
                        F[0] = xka - x[i-1] - h*(f(h*(i-1), x[i-1], y[i-1]));
                        F[1] = yka - y[i-1] - h*(g(h*(i-1), x[i-1], y[i-1]));
                        w[0] = F[0]*(1+h) - F[1]*h;
                        w[1] = F[0]*h + F[1]*(1-h);
                        x[i] = xka - w[0];
                        y[i] = yka - w[1];
                } while(Math.abs(w[0]-w[1])*Math.abs(w[0]-w[1]) >= e);
                      //ßâíèé ìåòîä Àäàìñà 3
             if(Math.abs(h*i - delta) <= lim && sw)
                {          sw = 1;
                        //h_st = h;
                        h = hmax;
                        i = (delta)/hmax;
                        n = 1/hmax+1;
                        
                }
             x[i] = x[i-1] + (h/12)*(23*f(h*(i-1),x[i-1],y[i-1]) - 16*f(h*(i-2), x[i-2], y[i-2]) + 5*f(h*(i-3), x[i-3], y[i-3]));
             y[i] = y[i-1] + (h/12)*(23*g(h*(i-1),x[i-1],y[i-1]) - 16*g(h*(i-2), x[i-2], y[i-2]) + 5*g(h*(i-3), x[i-3], y[i-3]));
        }
        var  t = 0;
        /*console.log(x.length)
        console.log(y);
        console.log(n);*/
        var rx=[],ry=[];
        var tt=[];
        for (var i=0;i< n;i++){
            var t=i*h;
            tt.push(t);
            xt.push(ft(t));
            yt.push(gt(t));
            rx.push(Math.abs(x[i]-ft(t)));
            ry.push(Math.abs(y[i]-gt(t)));
        }
    return new  Result(h,tt,x,y,xt,yt,rx,ry); 
}
module.exports=calculate;