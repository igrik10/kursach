window.onload=function(){
    var count=0,
        T=$("#view > tbody >tr:last");
        T.css("display","inline-table");
        for (var i=0;i<data.t.length;i++){
            if (data.t[i]>=0.1*count){
                T.append("<tr><td>"+data.t[i].toFixed(1)+"</td><td>"+data.x[i]+"</td><td>"+
                    data.y[i]+"</td><td>"+data.xt[i]+"</td><td>"+data.yt[i]+"</td><td>"+
                    data.rx[i]+"</td><td>"+data.ry[i]+"</td></tr>");
                count++;
            }
                
        }

}
       
       