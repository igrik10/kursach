//---------------------------------------------------------------------------

#include <vcl.h>
#include <math.h>
#pragma hdrstop

#include "Unit1.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TForm1 *Form1;
//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------

void __fastcall TForm1::FormCreate(TObject *Sender)
{
        StringGrid1->ColWidths[0] = 64;
        StringGrid2->ColWidths[0] = 64;
        StringGrid1->Cells[0][0] = "t";
        StringGrid2->Cells[0][0] = "t";
        StringGrid1->Cells[1][0] = "X";
        StringGrid2->Cells[1][0] = "X";
        StringGrid1->Cells[2][0] = "Y";
        StringGrid2->Cells[2][0] = "Y";
        for(int i = 1; i < 12; i++)
        {
                double t = 0.1*(i-1);
                StringGrid1->Cells[0][i] = FloatToStr(t);
                StringGrid2->Cells[0][i] = FloatToStr(t);
                StringGrid2->Cells[1][i] = FloatToStr(t*t);
                StringGrid2->Cells[2][i] = FloatToStr(t+1);

        }
}
double f(double t, double x, double y)
{
        return 2*x-y-2*t*t+3*t+1;
}
double g(double t, double x, double y)
{
        return x-2*y-t*t+2*t+3;
}
//---------------------------------------------------------------------------
void __fastcall TForm1::Button1Click(TObject *Sender)
{
        double h,e;
        h = StrToFloat(Edit1->Text);
        e = StrToFloat(Edit2->Text);
        double *x, *y, xcer, ycer, x1, y1, x0,y0, xka, yka;
        double k1, k2, k3, k4;
        int i, n, vuvel=0;
        x0 = 0;
        y0 = 1;
        k1 = f(0,x0,y0);
        k2 = f(h/2,x0+k1*h/2, y0+k1*h/2);
        k3 = f(h/2,x0+k2*h/2, y0+k2*h/2);
        k4 = f(h,x0+k3*h, y0+k3*h);
        xcer=x0+h/6*(k1+2*k2+2*k3+k4);
        k1 = g(0,x0,y0);
        k2 = g(h/2,x0+k1*h/2, y0+k1*h/2);
        k3 = g(h/2,x0+k2*h/2, y0+k2*h/2);
        k4 = g(h,x0+k3*h, y0+k3*h);
        ycer=y0+h/6*(k1+2*k2+2*k3+k4);
        //������ ���� �������������� ��4
        do{
                x1=xcer;
                y1=ycer;

                k1 = f(0,x0,y0);
                k2 = f(h/2,x0+k1*h/2, y0+k1*h/2);
                k3 = f(h/2,x0+k2*h/2, y0+k2*h/2);
                k4 = f(h,x0+k3*h, y0+k3*h);
                xcer=x0+h/6*(k1+2*k2+2*k3+k4);

                k1 = g(0,x0,y0);
                k2 = g(h/2,x0+k1*h/2, y0+k1*h/2);
                k3 = g(h/2,x0+k2*h/2, y0+k2*h/2);
                k4 = g(h,x0+k3*h, y0+k3*h);
                ycer=y0+h/6*(k1+2*k2+2*k3+k4);
                h=h/2;
                k1 = f(0,x0,y0);
                k2 = f(h/2,x0+k1*h/2, y0+k1*h/2);
                k3 = f(h/2,x0+k2*h/2, y0+k2*h/2);
                k4 = f(h,x0+k3*h, y0+k3*h);
                xka=x0+h/6*(k1+2*k2+2*k3+k4);

                k1 = g(0,x0,y0);
                k2 = g(h/2,x0+k1*h/2, y0+k1*h/2);
                k3 = g(h/2,x0+k2*h/2, y0+k2*h/2);
                k4 = g(h,x0+k3*h, y0+k3*h);
                yka=y0+h/6*(k1+2*k2+2*k3+k4);

        }while(fabs(xka-x1)+fabs(yka-y1)>=e);
        n = 1/h + 1;
        x = new double[n+1];
        y = new double[n+1];
        x[0] = x0;
        y[0] = y0;
        x[1] = xka;
        y[1] = yka;

        for(i=2; i<=n; i++)
        {
                x[i] = x[i-1];
                y[i] = y[i-1];
                do
                {
                        xka=x[i];
                        yka=y[i];
                        x[i]=x[i-1]+h*f(h*(i-1),x[i-1],y[i-1]);//��������� ���������� ������� ��������
                        y[i]=y[i-1]+h*g(h*(i-1),x[i-1],y[i-1]);
                } while(fabs(xka-x[i])+fabs(yka-y[i])>=e);
                x[i]=(4.0/3.0)*x[i-1]-(1.0/3.0)*x[i-2]+(2.0/3.0)*h*f(h*i,x[i],y[i]);//��������� �� ������� ������� ó��
                y[i]=(4.0/3.0)*y[i-1]-(1.0/3.0)*y[i-2]+(2.0/3.0)*h*g(h*i,x[i],y[i]);
        }
        StringGrid1->Cells[0][1] = 0.1*vuvel;
        StringGrid1->Cells[1][1] = x[0];
        StringGrid1->Cells[2][1] = y[0];
        vuvel++;
        for(i = 1; i <=n; i++)
        {
                if(h*i>=vuvel*0.1)
                {
                        StringGrid1->Cells[0][vuvel+1] = vuvel*0.1;
                        StringGrid1->Cells[1][vuvel+1] = x[i];
                        StringGrid1->Cells[2][vuvel+1] = y[i];
                        vuvel++;
                }
        }
        StringGrid1->Cells[0][11] = 1;
        StringGrid1->Cells[1][11] = x[n];
        StringGrid1->Cells[2][11] = y[n];
        MessageBox(NULL, FloatToStr(h).c_str(), "Krok", 0);
}
//---------------------------------------------------------------------------


T.append("<tr><td>X</td><td>Y</td><td>Xt</td><td>Yt</td></tr><td>Residual(x)</td><td>Residual(y)</td></tr>");
         for (var i=0;i<x.length;i++){
                T.append("<tr><td>"+x[i]+"</td><td>"+y[i]+"</td><td>"+f_t(h*(i))+"</td><td>"+g_t(h*(i))+"</td><td>"+x[i]-f_t(h*(i))+"</td><td>"+y[i]-g_t(h*(i))+"</td></tr></tr>");
         }