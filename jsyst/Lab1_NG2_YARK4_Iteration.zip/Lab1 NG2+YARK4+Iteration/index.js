function f( t,  x,  y)
{
        return 2*x-y-2*t*t+3*t+1;
}
function g( t,  x,  y)
{
        return x-2*y-t*t+2*t+3;
}
function f_t(t,x,y){
        return t*t;
}
function g_t(t,x,y){
        return t+1;
}
//
//---------------------------------------------------------------------------
function doit()
{
        //console.log("asf");
        var h,e;
        h = parseFloat($("#h").val());
        e = parseFloat($("#e").val());
        console.log(h);console.log(typeof h);
        var x, y, xcer, ycer, x1, y1, x0,y0, xka, yka;
        var k1, k2, k3, k4;
        var i, n, vuvel=0;
        x0 = 0;
        y0 = 1;
        k1 = f(0,x0,y0);
        k2 = f(h/2,x0+k1*h/2, y0+k1*h/2);
        k3 = f(h/2,x0+k2*h/2, y0+k2*h/2);
        k4 = f(h,x0+k3*h, y0+k3*h);
        xcer=x0+h/6*(k1+2*k2+2*k3+k4);
        k1 = g(0,x0,y0);
        k2 = g(h/2,x0+k1*h/2, y0+k1*h/2);
        k3 = g(h/2,x0+k2*h/2, y0+k2*h/2);
        k4 = g(h,x0+k3*h, y0+k3*h);
        ycer=y0+h/6*(k1+2*k2+2*k3+k4);
        //øóêàºìî êðîê âèêîðèñòîâóþ÷è ÐÊ4
        do{
                x1=xcer;
                y1=ycer;

                k1 = f(0,x0,y0);
                k2 = f(h/2,x0+k1*h/2, y0+k1*h/2);
                k3 = f(h/2,x0+k2*h/2, y0+k2*h/2);
                k4 = f(h,x0+k3*h, y0+k3*h);
                xcer=x0+h/6*(k1+2*k2+2*k3+k4);

                k1 = g(0,x0,y0);
                k2 = g(h/2,x0+k1*h/2, y0+k1*h/2);
                k3 = g(h/2,x0+k2*h/2, y0+k2*h/2);
                k4 = g(h,x0+k3*h, y0+k3*h);
                ycer=y0+h/6*(k1+2*k2+2*k3+k4);
                h=h/2;
                k1 = f(0,x0,y0);
                k2 = f(h/2,x0+k1*h/2, y0+k1*h/2);
                k3 = f(h/2,x0+k2*h/2, y0+k2*h/2);
                k4 = f(h,x0+k3*h, y0+k3*h);
                xka=x0+h/6*(k1+2*k2+2*k3+k4);

                k1 = g(0,x0,y0);
                k2 = g(h/2,x0+k1*h/2, y0+k1*h/2);
                k3 = g(h/2,x0+k2*h/2, y0+k2*h/2);
                k4 = g(h,x0+k3*h, y0+k3*h);
                yka=y0+h/6*(k1+2*k2+2*k3+k4);

        }while(Math.abs(xka-x1)+Math.abs(yka-y1)>=e);
        n = 1/h + 1;
        x = [];
        y = [];
        x[0] = x0;
        y[0] = y0;
        x[1] = xka;
        y[1] = yka;

        for(i=2; i<=n; i++)
        {
                x[i] = x[i-1];
                y[i] = y[i-1];
                do
                {
                        xka=x[i];
                        yka=y[i];
                        x[i]=x[i-1]+h*f(h*(i-1),x[i-1],y[i-1]);//óòî÷íþºìî íàáëèæåííÿ ìåòîäîì ³òåðàö³é
                        y[i]=y[i-1]+h*g(h*(i-1),x[i-1],y[i-1]);
                } while(Math.abs(xka-x[i])+Math.abs(yka-y[i])>=e);
                x[i]=(4.0/3.0)*x[i-1]-(1.0/3.0)*x[i-2]+(2.0/3.0)*h*f(h*i,x[i],y[i]);//çíàõîäèìî çà íåÿâíèì ìåòîäîì Ã³ðà
                y[i]=(4.0/3.0)*y[i-1]-(1.0/3.0)*y[i-2]+(2.0/3.0)*h*g(h*i,x[i],y[i]);
        }
         console.log(x);
        console.log(y);
        console.log("as");


        var T=$("#tabl > tbody >tr:last");
        T.css("display","inline-block");
         T.append("<tr><td>X</td><td>Y</td><td>Xt</td><td>Yt</td></tr>");
         for (var i=0;i<x.length;i++){
                T.append("<tr><td>"+x[i]+"</td><td>"+y[i]+"</td><td>"+f_t(h*(i))+"</td><td>"+g_t(h*(i))+"</td></tr>");
        }
        /*StringGrid1->Cells[0][1] = 0.1*vuvel;
        StringGrid1->Cells[1][1] = x[0];
        StringGrid1->Cells[2][1] = y[0];
        vuvel++;
        for(i = 1; i <=n; i++)
        {
                if(h*i>=vuvel*0.1)
                {
                        StringGrid1->Cells[0][vuvel+1] = vuvel*0.1;
                        StringGrid1->Cells[1][vuvel+1] = x[i];
                        StringGrid1->Cells[2][vuvel+1] = y[i];
                        vuvel++;
                }
        }
        StringGrid1->Cells[0][11] = 1;
        StringGrid1->Cells[1][11] = x[n];
        StringGrid1->Cells[2][11] = y[n];
        MessageBox(NULL, FloatToStr(h).c_str(), "Krok", 0);*/
       

}
function a(){
        console.log("a");
}
//---------------------------------------------------------------------------


